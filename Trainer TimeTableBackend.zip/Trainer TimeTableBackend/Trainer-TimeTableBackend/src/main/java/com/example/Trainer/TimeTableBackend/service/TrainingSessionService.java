package com.example.Trainer.TimeTableBackend.service;

import com.example.Trainer.TimeTableBackend.entity.TrainingSession;

import java.util.Map;

public interface TrainingSessionService {
    TrainingSession addSession(TrainingSession session);
    Map<String, Long> getTotalSessionsByTrainer();
    Long getTotalSessions();
    Long getConfirmedSessions();
    Long getTotalParticipants();
}
