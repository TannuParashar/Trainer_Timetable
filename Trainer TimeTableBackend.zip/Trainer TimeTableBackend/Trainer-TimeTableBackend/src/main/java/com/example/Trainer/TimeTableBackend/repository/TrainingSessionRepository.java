package com.example.Trainer.TimeTableBackend.repository;
import com.example.Trainer.TimeTableBackend.entity.TrainingSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
public interface TrainingSessionRepository extends JpaRepository<TrainingSession, Long>{
    long countByTrainer(String trainer);

    long countByStatus(String status);

    @Query("SELECT COALESCE(SUM(t.participants), 0) FROM TrainingSession t")
    Long sumParticipants();
}
