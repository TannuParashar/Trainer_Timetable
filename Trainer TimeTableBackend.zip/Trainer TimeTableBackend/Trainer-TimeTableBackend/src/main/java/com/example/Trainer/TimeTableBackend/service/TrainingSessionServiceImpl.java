package com.example.Trainer.TimeTableBackend.service;

import com.example.Trainer.TimeTableBackend.entity.TrainingSession;
import com.example.Trainer.TimeTableBackend.repository.TrainingSessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TrainingSessionServiceImpl implements TrainingSessionService{
    private static final List<String> TRAINERS = Arrays.asList("Sarah Johnson", "Mike Chen", "Lisa Rodriguez");

    @Autowired
    private TrainingSessionRepository sessionRepository;

    @Override
    public TrainingSession addSession(TrainingSession session) {
        if (!TRAINERS.contains(session.getTrainer())) {
            throw new IllegalArgumentException("Invalid trainer name");
        }
        return sessionRepository.save(session);
    }

    @Override
    public Map<String, Long> getTotalSessionsByTrainer() {
        Map<String, Long> result = new HashMap<>();
        for (String trainer : TRAINERS) {
            result.put(trainer, sessionRepository.countByTrainer(trainer));
        }
        return result;
    }

    @Override
    public Long getTotalSessions() {
        return sessionRepository.count();
    }

    @Override
    public Long getConfirmedSessions() {
        return sessionRepository.countByStatus("Confirmed");
    }

    @Override
    public Long getTotalParticipants() {
        return sessionRepository.sumParticipants();
    }
}
