package com.example.Trainer.TimeTableBackend.controller;

import com.example.Trainer.TimeTableBackend.entity.TrainingSession;
import com.example.Trainer.TimeTableBackend.repository.TrainingSessionRepository;
import com.example.Trainer.TimeTableBackend.service.TrainingSessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sessions")
@CrossOrigin("*")
public class TrainingSessionController {

    @Autowired
    private TrainingSessionService sessionService;

    @PostMapping("/add")
    public TrainingSession addSession(@RequestBody TrainingSession session) {
        return sessionService.addSession(session);
    }

    @GetMapping("/count/by-trainer")
    public Map<String, Long> getTotalSessionsByTrainer() {
        return sessionService.getTotalSessionsByTrainer();
    }

    @GetMapping("/count/total")
    public Long getTotalSessions() {
        return sessionService.getTotalSessions();
    }

    @GetMapping("/count/confirmed")
    public Long getConfirmedSessions() {
        return sessionService.getConfirmedSessions();
    }

    @GetMapping("/count/participants")
    public Long getTotalParticipants() {
        return sessionService.getTotalParticipants();
    }
}

