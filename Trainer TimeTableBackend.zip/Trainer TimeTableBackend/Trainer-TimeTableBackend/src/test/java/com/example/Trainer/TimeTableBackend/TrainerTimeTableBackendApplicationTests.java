package com.example.Trainer.TimeTableBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainerTimeTableBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
